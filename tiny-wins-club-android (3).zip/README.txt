TINY WINS CLUB - Android app project (NOT compiled or tested by Claude)

What this adds over the web version
- Real phone time: reads Android usage stats (you grant "usage access" once).
- Focus mode: Do Not Disturb (alarms only) while a focus or hands-off timer runs.
- Real reminders: daily notifications even when the app is closed.

Get an APK without installing anything (free):
1. Make a free GitHub account, create a new repository, upload everything in this folder (keep the .github folder).
2. Open the Actions tab, run "Build APK" (it also runs on every upload). Wait about 5 minutes.
3. Open the finished run, download the "TinyWinsClub-debug-apk" artifact, unzip it, send app-debug.apk to your phone and open it (allow "install unknown apps" when asked).
4. In the app: Settings (gear) -> Phone permissions -> allow usage access, Do Not Disturb, notifications.

Or open this folder in Android Studio and press Run.

Play Store: needs a Google Play developer account (one-time $25), a signed release build (not the debug one), a privacy policy page, and a Play declaration for the usage-access permission. Plan for review time.
iPhone: Apple does not let third-party apps read screen time or silence notifications without a special Screen Time entitlement and a paid developer account, so the iPhone version stays the home-screen web app.

The app files live in app/src/main/assets/www. To update the game, replace index.html there.

NOTIFICATIONS: the app asks for notification permission on first launch. Open Settings (gear) -> Send a test notification to check. If reminders arrive late, turn off battery optimization for Tiny Wins Club in Android settings (Apps -> Tiny Wins Club -> Battery -> Unrestricted) and allow Exact reminder times.
