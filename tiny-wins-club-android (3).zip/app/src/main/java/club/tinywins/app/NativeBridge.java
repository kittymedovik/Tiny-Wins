package club.tinywins.app;

import android.Manifest;
import android.app.Activity;
import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.app.usage.UsageEvents;
import android.content.pm.PackageManager;
import android.net.Uri;
import java.util.HashMap;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;

/** Methods the web app calls as window.TinyNative.*  Everything here is untested on a real device. */
public class NativeBridge {
    private final Activity act;
    NativeBridge(Activity a) { act = a; }

    @JavascriptInterface public boolean hasUsageAccess() {
        AppOpsManager ops = (AppOpsManager) act.getSystemService(Context.APP_OPS_SERVICE);
        int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), act.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }
    @JavascriptInterface public void openUsageSettings() {
        Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (Build.VERSION.SDK_INT >= 29) i.setData(Uri.parse("package:" + act.getPackageName()));
        try { act.startActivity(i); } catch (Exception e) { act.startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
    }
    /** Sums foreground time per app today from usage events (like Digital Wellbeing). Returns JSON. */
    @JavascriptInterface public String getUsageToday() {
        try {
            UsageStatsManager um = (UsageStatsManager) act.getSystemService(Context.USAGE_STATS_SERVICE);
            Calendar c = Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
            long start = c.getTimeInMillis(), end = System.currentTimeMillis();
            UsageEvents ev = um.queryEvents(start, end);
            UsageEvents.Event e = new UsageEvents.Event();
            HashMap<String, Long> resumed = new HashMap<>(), total = new HashMap<>();
            int count = 0;
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                count++;
                String pkg = e.getPackageName();
                int type = e.getEventType();
                if (type == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    resumed.put(pkg, e.getTimeStamp());
                } else if (type == UsageEvents.Event.MOVE_TO_BACKGROUND) {
                    Long r = resumed.remove(pkg);
                    if (r != null && e.getTimeStamp() > r) add(total, pkg, e.getTimeStamp() - r);
                } else if (type == 16 || type == 17) { // screen off / keyguard shown: close everything
                    for (Map.Entry<String, Long> en : resumed.entrySet()) if (e.getTimeStamp() > en.getValue()) add(total, en.getKey(), e.getTimeStamp() - en.getValue());
                    resumed.clear();
                }
            }
            for (Map.Entry<String, Long> en : resumed.entrySet()) if (end > en.getValue()) add(total, en.getKey(), end - en.getValue());
            PackageManager pm = act.getPackageManager();
            ArrayList<Object[]> rows = new ArrayList<>();
            long sum = 0;
            for (Map.Entry<String, Long> en : total.entrySet()) {
                String pkg = en.getKey();
                if (pkg.equals(act.getPackageName()) || en.getValue() < 30000) continue;
                if (pm.getLaunchIntentForPackage(pkg) == null) continue; // skip system pieces and launchers
                String name = pkg;
                try { name = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(); } catch (Exception x) {}
                rows.add(new Object[]{name, en.getValue()});
                sum += en.getValue();
            }
            Collections.sort(rows, new Comparator<Object[]>() {
                public int compare(Object[] a, Object[] b) { return Long.compare((Long) b[1], (Long) a[1]); }
            });
            JSONArray apps = new JSONArray();
            for (int i = 0; i < rows.size() && i < 5; i++) apps.put(new JSONObject().put("name", rows.get(i)[0]).put("minutes", Math.round((Long) rows.get(i)[1] / 60000.0)));
            return new JSONObject().put("minutes", Math.round(sum / 60000.0)).put("apps", apps).put("events", count).toString();
        } catch (Exception ex) {
            try { return new JSONObject().put("error", String.valueOf(ex)).toString(); } catch (Exception x) { return "null"; }
        }
    }
    private static void add(HashMap<String, Long> m, String k, long v) { Long o = m.get(k); m.put(k, (o == null ? 0 : o) + v); }
    @JavascriptInterface public void openAppSettings() {
        act.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + act.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }
    @JavascriptInterface public void openExactSettings() {
        if (Build.VERSION.SDK_INT >= 31) act.startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + act.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }
    /** json: [{id, at: epoch millis, label}] one-off alarms (task deadlines, adventure returns). */
    @JavascriptInterface public void setAlarms(String json) {
        act.getSharedPreferences("tw", Context.MODE_PRIVATE).edit().putString("once", json).apply();
        ReminderReceiver.scheduleAll(act);
    }

    @JavascriptInterface public boolean hasDndAccess() {
        return ((NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE)).isNotificationPolicyAccessGranted();
    }
    @JavascriptInterface public void openDndSettings() {
        act.startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }
    /** on=true: alarms only (silences notifications and calls). on=false: restore what the user had. */
    @JavascriptInterface public void setDnd(boolean on) {
        NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) return;
        SharedPreferences p = act.getSharedPreferences("tw", Context.MODE_PRIVATE);
        if (on) {
            if (!p.contains("prevFilter")) p.edit().putInt("prevFilter", nm.getCurrentInterruptionFilter()).apply();
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS);
        } else if (p.contains("prevFilter")) {
            int prev = p.getInt("prevFilter", NotificationManager.INTERRUPTION_FILTER_ALL);
            nm.setInterruptionFilter(prev == NotificationManager.INTERRUPTION_FILTER_UNKNOWN ? NotificationManager.INTERRUPTION_FILTER_ALL : prev);
            p.edit().remove("prevFilter").apply();
        }
    }

    @JavascriptInterface public boolean hasNotifPermission() {
        if (Build.VERSION.SDK_INT < 33) return true;
        return act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }
    @JavascriptInterface public void requestNotif() {
        if (Build.VERSION.SDK_INT >= 33) act.runOnUiThread(new Runnable() { public void run() {
            act.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }});
    }
    @JavascriptInterface public void testNotification() { ReminderReceiver.show(act, 99999, "Notifications are working. Your pals say hi!"); }
    /** json: [{id,t:"HH:MM",label}]  Saved and scheduled as daily repeating reminders. */
    @JavascriptInterface public void setReminders(String json) {
        act.getSharedPreferences("tw", Context.MODE_PRIVATE).edit().putString("rems", json).apply();
        ReminderReceiver.scheduleAll(act);
    }
}
